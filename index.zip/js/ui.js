// UI helpers (reserved)
