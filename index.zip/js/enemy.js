// Enemy helper (reserved)
